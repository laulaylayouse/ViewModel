package com.example.notesappviewmodel_laila_

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ViewModel(application: Application): AndroidViewModel(application) {

    private val NotesDao = NotesDatabase.getInstance(application).NotesDao()
    private val list_notes: LiveData<List<Table_Notes>>

    init {
        val NotesDao = NotesDatabase.getInstance(application).NotesDao()
        list_notes = NotesDao.getAllNotes()
    }

    fun getAll(): LiveData<List<Table_Notes>>{
        return list_notes
    }

    fun add(Text: String){
        CoroutineScope(Dispatchers.IO).launch {
            NotesDao.insertNote(Table_Notes(0,Text))
        }
    }

    fun Update(id: Int, Text: String){
        CoroutineScope(Dispatchers.IO).launch {
            NotesDao.update(Text,id)
        }
    }

    fun delete(id: Int, Text: String){
        CoroutineScope(Dispatchers.IO).launch {
            NotesDao.deleteOBJ(Table_Notes(id,Text))
        }
    }
}