package com.example.notesappviewmodel_laila_

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView

    lateinit var EditText_add_Name: EditText
    lateinit var Button_Save: Button

    lateinit var note_Adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Recycler_View = findViewById(R.id.Recycler_View)
        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        Button_Save = findViewById(R.id.Button_Save)


        ViewModelProvider(this).get(ViewModel::class.java).getAll().observe(this, {
                notes -> note_Adapter = Adapter(this, notes)
            Recycler_View.adapter = note_Adapter
            Recycler_View.layoutManager = LinearLayoutManager(this)
        })

        Button_Save.setOnClickListener {
            val note = EditText_add_Name.text.toString()
            ViewModelProvider(this).get(ViewModel::class.java).add(note)
            EditText_add_Name.setText("")
        }

    }


    fun Update( id_Update: Int, name_delete:String){
        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this)
        val Update_Note = EditText(this)
        var Note = ""
        Update_Note.setText("$name_delete")
        dialogBuilder.setMessage("")
            .setPositiveButton("Update", DialogInterface.OnClickListener {
                    _, _ ->
                Toast.makeText(applicationContext, "$id_Update", Toast.LENGTH_SHORT).show()
                Note = Update_Note.text.toString()
                ViewModelProvider(this).get(ViewModel::class.java).Update(id_Update,Note)
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, _ -> dialog.cancel()
            })
        val alertDialog = dialogBuilder.create()
        alertDialog.setTitle("Update Note $id_Update")
        alertDialog.setView(Update_Note)
        alertDialog.show()


    }

    fun Delete( id_delete: Int , name_delete: String){
        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this)
        dialogBuilder.setMessage("Are you sure you want to delete Note $id_delete?")
            .setPositiveButton("Delete", DialogInterface.OnClickListener {
                    _, _ ->
                ViewModelProvider(this).get(ViewModel::class.java).delete(id_delete, name_delete)
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, _ -> dialog.cancel()
            })

        val alertDialog = dialogBuilder.create()
        alertDialog.setTitle("Delete Note $id_delete")
        alertDialog.show()
    }
}